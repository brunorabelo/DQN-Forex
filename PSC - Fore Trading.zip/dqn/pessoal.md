Ideia

melhorias: 
 - mini batch size
 - replays
 - target network

Criar varios cenários:

reward:
 - patrimonio total pnl
 - dinheiro em caixa
 - ratio sortino
 - sharpe

periodos:
 - diario
 - 12h
 - 8h

Normalizar -> começar por 1 (divide todos os valores pelo valor do 
primeiro dia)